homeModule.factory('changePassword',function($http){
    return function (params) {
        return $http.post(appUrl+'change_password?token='+localStorage.getItem('token'), $.param(params),{headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
        })
    }
});
