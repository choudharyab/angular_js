var bankAccountModule=angular.module('bankAccountModule',[]);
bankAccountModule.controller('bankAccountController',['$rootScope','$scope','$location','getWarehouseListService','getCashInHandDetails','getBankAccountDetails','getBankOccDetails',
    function($rootScope,$scope,$location,getWarehouseListService,getCashInHandDetails,getBankAccountDetails,getBankOccDetails){

    getWarehouseListService({}).then(function (response) {
        $scope.warehouse_list = response.data;
    });
    $scope.grand_total_cr=0;
        $scope.grand_total_db=0;
    //var cash_cr,cash_db,bank_acc_cr,bank_acc_db,bank_occ_cr,bank_occ_db;
        $scope.finance_year = new Date().getFullYear();
        $scope.current_month = new Date().getMonth();
        if($scope.current_month<3){
            $scope.finance_year--;
        }
        $scope.current_month++;
        $rootScope.from_date = $scope.finance_year +'-04'+'-01';
        $rootScope.to_date = $scope.finance_year+1+'-03'+'-31';

        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
        $scope.get_wh = function () {
            $rootScope.warehouse_id = $scope.warehouse_id;
            for(i=0;i<$scope.warehouse_list.length;i++){
                if($scope.warehouse_list[i].id==$scope.warehouse_id)
                $scope.warehouse_data=$scope.warehouse_list[i];
            }
            localStorage.setItem('warehouse_id',($scope.warehouse_data).id);
            localStorage.setItem('warehouse_name',($scope.warehouse_data).warehouse_name);
            console.log('warehouse_name----->',localStorage.getItem('warehouse_name'));
            $scope.selected_warehouse = localStorage.getItem('warehouse_id');
            $rootScope.selected_warehouse_name = localStorage.getItem('warehouse_name');
            //$route.reload();
        };

        $scope.getAllBankAccountsList=function () {
			$rootScope.from_date = $scope.from_date; 
			$rootScope.to_date = $scope.to_date;
			
            $scope.grand_total_cr=0;
            $scope.grand_total_db=0;
            getCashInHandDetails({
                from_date:$rootScope.from_date,
                to_date:$rootScope.to_date,
                warehouse_id:$rootScope.warehouse_id
            }).then(function (response) {
                console.log(response);
                $scope.cash_in_hand_list=response.data.cash_in_hand_details;
                /*list=response.data;*/
                $scope.total_cash_credit=0;
                $scope.total_cash_debit=0;
                for(var i=0;i<$scope.cash_in_hand_list.length;i++)
                {
                    $scope.total_cash_credit+=parseFloat($scope.cash_in_hand_list[i].credit_amount);
                    $scope.total_cash_debit+=parseFloat($scope.cash_in_hand_list[i].debit_amount);
                }
                console.log('total credit amount------',$scope.total_cash_credit);
                console.log('total debit amount------',$scope.total_cash_debit);
                $scope.grand_total_cr+=$scope.total_cash_credit;
                $scope.grand_total_db+=$scope.total_cash_debit;
				
				$scope.cash_in_hand_total_credit_amount = response.data.cash_in_hand_total_credit_amount;
				$scope.cash_in_hand_total_debit_amount = response.data.cash_in_hand_total_debit_amount;
            },function(response){
                console.log(response);
            });
            getBankAccountDetails({
                from_date:$rootScope.from_date,
                to_date:$rootScope.to_date,
                warehouse_id:$rootScope.warehouse_id
            }).then(function (response) {
                console.log(response);
                $scope.bank_account_list=response.data.bank_account_details;
                $scope.total_credit_amount=response.data.bank_account_total_credit_amount;
                $scope.total_debit_amount=response.data.bank_account_total_debit_amount;
				$scope.bank_account_total_credit_amount = response.data.bank_account_total_credit_amount;
				$scope.bank_account_total_debit_amount = response.data.bank_account_total_debit_amount;
                /*list=response.data;*/
                $scope.total_bank_account_credit=0;
                $scope.total_bank_account_credit=0;
                $scope.total_bank_account_debit=0;
                /*for(var j=0;j<$scope.bank_account_list.length;j++)
                {
                if($scope.bank_account_list[j].credit_amount == '' || $scope.bank_account_list[j].credit_amount == null || 	$scope.bank_account_list[j].credit_amount == undefined){
                        $scope.bank_account_list[j].credit_amount = 0;
                    }

                   if($scope.bank_account_list[j].debit_amount == '' || $scope.bank_account_list[j].debit_amount == null || $scope.bank_account_list[j].debit_amount == undefined){
                        $scope.bank_account_list[j].debit_amount = 0;
                    }
                    $scope.total_bank_account_credit+=parseFloat($scope.bank_account_list[j].credit_amount);
                    $scope.total_bank_account_debit+=parseFloat($scope.bank_account_list[j].debit_amount);
                }*/
                for(var j=0;j<$scope.bank_account_list.length;j++)
                {
                    if($scope.bank_account_list[j].credit_amt == '' || $scope.bank_account_list[j].credit_amt == null || $scope.bank_account_list[j].credit_amt == undefined){
                        $scope.bank_account_list[j].credit_amt = 0;
                    }

                    if($scope.bank_account_list[j].debit_amt == '' || $scope.bank_account_list[j].debit_amt == null || $scope.bank_account_list[j].debit_amt == undefined){
                        $scope.bank_account_list[j].debit_amt = 0;
                    }
                    console.log('$scope.bank_account_list.length--->',$scope.bank_account_list[j].credit_amt);
                    $scope.total_bank_account_credit = parseFloat($scope.total_bank_amount.bank_account_total_credit_amount);
                    $scope.total_bank_account_debit=parseFloat($scope.total_bank_amount.bank_account_total_debit_amount);
                }
                //console.log('total credit amount------',$scope.total_bank_account_credit);
                //console.log('total debit amount------',$scope.total_bank_account_debit);
                $scope.grand_total_cr+=$scope.total_bank_account_credit;
                $scope.grand_total_db+=$scope.total_bank_account_debit;
            },function(response){
                console.log(response);
            });
            getBankOccDetails({
                from_date:$rootScope.from_date,
                to_date:$rootScope.to_date,
                warehouse_id:$rootScope.warehouse_id
            }).then(function (response) {
                console.log(response);
                $scope.bank_occ_list=response.data.bank_occ_details;
                /*list=response.data;*/
                $scope.total_bank_occ_credit=0;
                $scope.total_bank_occ_debit=0;
                for(var k=0;k<$scope.bank_occ_list.length;k++)
                {
                    $scope.total_bank_occ_credit+=parseFloat($scope.bank_occ_list[k].credit_amount);
                    $scope.total_bank_occ_debit+=parseFloat($scope.bank_occ_list[k].debit_amount);
                }
                //console.log('total credit amount------',$scope.total_bank_occ_credit);
                //console.log('total debit amount------',$scope.total_bank_occ_debit);
				$scope.total_credit_amount_data = response.data.total_credit_amount;
				$scope.total_debit_amount_data = response.data.total_debit_amount;
                $scope.grand_total_cr+=$scope.total_bank_occ_credit;
                $scope.grand_total_db+=$scope.total_bank_occ_debit;
            },function(response){
                console.log(response);
            });


        };
        $scope.getAllBankAccountsList();
		$scope.convertCrDr = function(value){
		var checkVal = value.toString().indexOf('-');
		if(checkVal === -1){
			return value+' DR';
		} else {
			var splitVal = value.toString().split('-');
			return splitVal[1]+' CR';
		}
	}

        $scope.cashInHandMonthWise = function (id,type) {
			$rootScope.from_date = $scope.from_date; 
			$rootScope.to_date = $scope.to_date;
            if($rootScope.warehouse_id == undefined){
                $scope.waree_id = 0;
            } else {
                $scope.waree_id = $rootScope.warehouse_id;
            }
            $rootScope.cash_ledger_id=id;
            if(type=='Ledger')
            {
                $location.path('/cashinhandmonthwise/'+id+'/'+$rootScope.from_date+'/'+$rootScope.to_date+'/'+$scope.waree_id);
            }
        };

        $scope.bankAccountMonthWise = function (id,type) {
			$rootScope.from_date = $scope.from_date; 
			$rootScope.to_date = $scope.to_date;
            if($rootScope.warehouse_id == undefined){
                $scope.waree_id = 0;
            } else {
                $scope.waree_id = $rootScope.warehouse_id;
            }
            $rootScope.bank_ledger_id=id;
            if(type=='Ledger')
            {
                $location.path('/bankaccountmonthwise/'+id+'/'+$rootScope.from_date+'/'+$rootScope.to_date+'/'+$scope.waree_id);
            }
        };

        $scope.bankOccMonthWise = function (id,type) {
			$rootScope.from_date = $scope.from_date; 
			$rootScope.to_date = $scope.to_date;
            if($rootScope.warehouse_id == undefined){
                $scope.waree_id = 0;
            } else {
                $scope.waree_id = $rootScope.warehouse_id;
            }
            $rootScope.Occ_ledger_id=id;
            if(type=='Ledger')
            {
                $location.path('/bankoccmonthwise/'+id+'/'+$rootScope.from_date+'/'+$rootScope.to_date+'/'+$scope.waree_id);
            }
        };

}]).controller('cashInHandMonthWiseController',['$rootScope','$scope','$routeParams','$location','getCashInHandMonthWiseDetails',function ($rootScope,$scope,$routeParams,$location,getCashInHandMonthWiseDetails) {

    //$rootScope.cash_ledger_id = $routeParams.ledger_id;
    $scope.frm_date = $routeParams.from_date;
    $scope.t_date = $routeParams.to_date;
    $scope.wre_id = $routeParams.warehouse_id;
    $scope.leg_id = $routeParams.ledger_id;
    getCashInHandMonthWiseDetails({
        from_date:$routeParams.from_date,
        to_date:$routeParams.to_date,
        warehouse_id:$routeParams.warehouse_id,
        ledger_id:$routeParams.ledger_id
    }).then(function (res) {
        $scope.cashInHandMonthWiseList = res.data.details;
        $scope.debit_opening_balance=res.data.debit_opening_balance;
        $scope.credit_opening_balance=res.data.credit_opening_balance;
        $scope.closing_balance=res.data.closing_balance;
        $scope.credit_total=res.data.credit_total;
        $scope.debit_total=res.data.debit_total;
        $scope.total_closing_bal = 0;
        for(var f=0;f<$scope.cashInHandMonthWiseList.length;f++){
            $scope.total_closing_bal += parseFloat($scope.cashInHandMonthWiseList[f].closing_balance);
        }
        $scope.total_closing_bal.toFixed(2);
    },function (res) {
        console.log(res);
    });
    $scope.cashInHandDateWise = function (route) {
        $location.path(route);
    };

}]).controller('cashInHandDateWiseController',['$rootScope','$scope','$routeParams','getCashInHandDateWiseDetails',function ($rootScope,$scope,$routeParams,getCashInHandDateWiseDetails) {

    console.log($routeParams.month_no);

    getCashInHandDateWiseDetails({
        from_date:$routeParams.from_date,
        to_date:$routeParams.to_date,
        warehouse_id:$routeParams.warehouse_id,
        month_no:$routeParams.month_no,
        ledger_id:$routeParams.ledger_id
    }).then(function (res) {
        $scope.ledger_details = res.data.details;
        $scope.debit_opening_balance=res.data.debit_opening_balance;
        $scope.credit_opening_balance=res.data.credit_opening_balance;
        $scope.debit_closing_balance=res.data.debit_closing_balance;
        $scope.credit_closing_balance=res.data.credit_closing_balance;
        $scope.credit_total=res.data.credit_total;
        $scope.debit_total=res.data.debit_total;
    },function (res) {
        console.log(res);
    });
}]).controller('bankAccountMonthWiseController',['$rootScope','$scope','$routeParams','$location','getBankAccountMonthWiseDetails',function ($rootScope,$scope,$routeParams,$location,getBankAccountMonthWiseDetails) {

        //$rootScope.cash_ledger_id = $routeParams.ledger_id;
        $scope.frm_date = $routeParams.from_date;
        $scope.to_date = $routeParams.to_date;
        $scope.wre_id = $routeParams.warehouse_id;
        $scope.leg_id = $routeParams.ledger_id;
        getBankAccountMonthWiseDetails({
            from_date:$routeParams.from_date,
            to_date:$routeParams.to_date,
            warehouse_id:$routeParams.warehouse_id,
            ledger_id:$routeParams.ledger_id
        }).then(function (res) {
            $scope.bankAccountMonthWiseList = res.data.details;
             $scope.debit_opening_balance=res.data.debit_opening_balance;
        $scope.credit_opening_balance=res.data.credit_opening_balance;
        $scope.start_opening_balance=res.data.start_opening_balance;
            $scope.debit_closing_balance=res.data.debit_closing_balance;
            $scope.credit_closing_balance=res.data.credit_closing_balance;
            $scope.credit_total=res.data.credit_total;
            $scope.debit_total=res.data.debit_total
            $scope.total_closing_bal = 0;
			 $scope.ledger_name=res.data.ledger_name;
            for(var f=0;f<$scope.bankAccountMonthWiseList.length;f++){
                $scope.total_closing_bal += parseFloat($scope.bankAccountMonthWiseList[f].closing_balance);
            }
            $scope.total_closing_bal.toFixed(2);
        },function (res) {
            console.log(res);
        });
        $scope.bankAccountDateWise = function (route) {
			//alert(route)
            $location.path(route);
        };

    }]).controller('bankAccountDateWiseController',['$rootScope','$scope','$routeParams','getBankAccountDateWiseDetails',function ($rootScope,$scope,$routeParams,getBankAccountDateWiseDetails) {

    console.log($routeParams.month_no);

    getBankAccountDateWiseDetails({
        from_date:$routeParams.from_date,
        to_date:$routeParams.to_date,
        warehouse_id:$routeParams.warehouse_id,
        month_no:$routeParams.month_no,
        ledger_id:$routeParams.ledger_id
    }).then(function (res) {
        $scope.ledger_details = res.data.details;
        $scope.debit_opening_balance=res.data.debit_opening_balance;
        $scope.credit_opening_balance=res.data.credit_opening_balance;
        $scope.start_closing_balance=res.data.start_closing_balance;
        $scope.debit_closing_balance=res.data.debit_closing_balance;
        $scope.credit_closing_balance=res.data.credit_closing_balance;
        $scope.credit_total=res.data.credit_total;
        $scope.debit_total=res.data.debit_total;
		   $scope.ledger_name=res.data.ledger_name;
    },function (res) {
        console.log(res);
    });
}]).controller('bankOccMonthWiseController',['$rootScope','$scope','$routeParams','$location','getBankOccMonthWiseDetails',function ($rootScope,$scope,$routeParams,$location,getBankOccMonthWiseDetails) {

        //$rootScope.cash_ledger_id = $routeParams.ledger_id;
        $scope.frm_date = $routeParams.from_date;
        $scope.t_date = $routeParams.to_date;
        $scope.wre_id = $routeParams.warehouse_id;
        $scope.leg_id = $routeParams.ledger_id;
        getBankOccMonthWiseDetails({
            from_date:$routeParams.from_date,
            to_date:$routeParams.to_date,
            warehouse_id:$routeParams.warehouse_id,
            ledger_id:$routeParams.ledger_id
        }).then(function (res) {
            $scope.bankOccMonthWiseList = res.data.details;
              $scope.debit_opening_balance=res.data.debit_opening_balance;
        $scope.credit_opening_balance=res.data.credit_opening_balance;
            $scope.closing_balance=res.data.closing_balance;
            $scope.credit_total=res.data.credit_total;
            $scope.debit_total=res.data.debit_total;
            $scope.ledger_name=res.data.ledger_name;
            $scope.total_closing_bal = 0;
            for(var f=0;f<$scope.bankOccMonthWiseList.length;f++){
                $scope.total_closing_bal += parseFloat($scope.bankOccMonthWiseList[f].closing_balance);
            }
            $scope.total_closing_bal.toFixed(2);
        },function (res) {
            console.log(res);
        });
        $scope.bankOccDateWise = function (route) {
            $location.path(route);
        };

    }]).controller('bankOccDateWiseController',['$rootScope','$scope','$routeParams','getBankOccDateWiseDetails',function ($rootScope,$scope,$routeParams,getBankOccDateWiseDetails) {

    console.log($routeParams.month_no);

    getBankOccDateWiseDetails({
        from_date:$routeParams.from_date,
        to_date:$routeParams.to_date,
        warehouse_id:$routeParams.warehouse_id,
        month_no:$routeParams.month_no,
        ledger_id:$routeParams.ledger_id
    }).then(function (res) {
        $scope.ledger_details = res.data.details;
          $scope.debit_opening_balance=res.data.debit_opening_balance;
        $scope.credit_opening_balance=res.data.credit_opening_balance;
        $scope.closing_balance=res.data.closing_balance;
        $scope.credit_total=res.data.credit_total;
        $scope.debit_total=res.data.debit_total;
    },function (res) {
        console.log(res);
    });
}])
;


