var generate_voucher = angular.module('generateVoucherModule',[]);
generate_voucher.controller('generateVoucherController',['$rootScope','$scope','$location','$filter','getVoucherTypeListService','addVoucherTypeService','getAccLedgerListService','addGenerateVoucherService','getGenerateVoucherListService','getVoucherLedgerListService','getWarehouseListService','getVoucherLedgerListForOpService',function($rootScope,$scope,$location,$filter,getVoucherTypeListService,addVoucherTypeService,getAccLedgerListService,addGenerateVoucherService,getGenerateVoucherListService,getVoucherLedgerListService,getWarehouseListService,getVoucherLedgerListForOpService){

    var led_list;
  
   $scope.voucher_date = $filter('date')(Date.now(), 'dd-MM-yyyy');
    getWarehouseListService({}).then(function (response) {
        $scope.warehouse_list = response.data;
    });

    $scope.get_wh = function () {
        $rootScope.warehouse_id = $scope.warehouse_id;
        $scope.get_po_warehouse();
    };

    $scope.$on('change_warehouse',function(event,data){
       
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
        $scope.get_voucher_list();

    });
     
      $scope.get_po_warehouse = function () {
        localStorage.setItem('warehouse_id',$rootScope.warehouse_id);
   
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
    };
    
    $scope.get_voucher_list = function () {
        getVoucherTypeListService({}).then(function (res) {
            console.log(res);
            $scope.voucher_type_list = res.data;
        });
    };
    $scope.get_voucher_list();

    $scope.create_voucher_function = function () {
        addVoucherTypeService({voucher_type_name:$scope.voucher_name}).then(function (res) {
            $scope.dismiss();
            $scope.voucher_add_success = JSON.parse(res.data);
            $('#vou_add_success').fadeIn().delay(5000).fadeOut();
            $scope.voucher_name = '';
            $scope.get_voucher_list();
        },function (res) {
            console.log(res);
        })
    };

    // $scope.get_ledger_list = function () {
    //     getVoucherLedgerListService({}).then(function (response) {
    //         $scope.led_list = response.data;
    //         for(var f=0;f<$scope.led_list.length;f++){
    //             $scope.led_list[f].value = $scope.led_list[f].ledger_name+'-'+ $scope.led_list[f].bank_account_no;
    //         }
    //         led_list = $scope.led_list;
    //     })
    // };
    // $scope.get_ledger_list();
    $scope.get_ledger_list = function () {
        getVoucherLedgerListForOpService({}).then(function (response) {
            $scope.led_list = response.data;
            for(var f=0;f<$scope.led_list.length;f++){
				 $scope.led_list[f].value = $scope.led_list[f].ledger_name;
			}
            led_list = $scope.led_list;
        })
    };
    $scope.get_ledger_list();

    $scope.generate_voucher_list = function () {
        getGenerateVoucherListService({}).then(function (res) {
            $scope.generate_vou_list = res.data;
        })
    };

    $scope.generate_voucher_list();

    $scope.$watch('debit_autocom',function () {
      $scope.get_debit_auto();
    });

    $scope.$watch('credit_autocom',function () {
        $scope.get_credit_auto();
    });

    $scope.get_debit_auto = function () {

        $('#debit_autocom').autocomplete({
            source:led_list,
            select:function (event,ui) {
                console.log(ui);
                $scope.debit_ledger_ld = ui.item.id;
				$scope.debit_ledger_type = ui.item.ledger_type;
            }
        });
    };
	
	
	$scope.debit_type_select = function(){
		var party_type_data = $('#debit_party_id').val();
		
		$scope.debit_ledger_type = party_type_data;
	}
	$scope.credit_type_select = function(){
		var party_type_data = $('#credit_party_id').val();
		
		$scope.credit_ledger_type = party_type_data;
	}

    $scope.get_credit_auto = function () {

        $('#credit_autocom').autocomplete({
            source:led_list,
            select:function (event,ui) {
				console.log(ui)
                $scope.credit_ledger_ld = ui.item.id;
				$scope.credit_ledger_type = ui.item.ledger_type;
            }
        });
    };
    $scope.copy_debit_amt = function () {
      $scope.credit_amount=$scope.debit_amount;
    };

    $scope.add_generate_voucher = function () {
		
		//alert($scope.warehouse_id.length)
		/* if($scope.warehouse_id == '' || $scope.warehouse_id == 'undefined',true){
		      // alert("select warehouse");
			  $('#pending_add_success').fadeIn().delay(5000).fadeOut();
                $scope.pending_add_success = 'select warehouse';
		  }else if($scope.voucher_type_id == '' || $scope.voucher_type_id == 'undefined',true)
		  {
			   $('#pending_add_success').fadeIn().delay(5000).fadeOut();
                $scope.pending_add_success = 'select voucher type';
		  }else if($scope.voucher_date == '' || $scope.voucher_date == 'undefined',true)
		  {
			   alert("select voucher date");
		  }
		  else{*/
        addGenerateVoucherService({
            voucher_type_id:$scope.voucher_type_id,
            voucher_date:$scope.voucher_date,
            debit_particulars_id:$scope.debit_ledger_ld,
            debit_amount:$scope.debit_amount,
            credit_particulars_id:$scope.credit_ledger_ld,
            credit_amount:$scope.credit_amount,
            narration:$scope.narration,
            warehouse_id:$scope.warehouse_id,
			credit_ledger_type:$scope.credit_ledger_type,
			debit_ledger_type:$scope.debit_ledger_type,
        }).then(function (res) {
            console.log(res);
            $scope.voucher_type_id = '';
           // $scope.voucher_date = '';
            $scope.debit_amount = '';
            $scope.credit_amount = '';
            $scope.debit_autocom = '';
            $scope.credit_autocom = '';
            $scope.debit_ledger_ld = '';
            $scope.credit_ledger_ld = '';
            $scope.narration='';

            $scope.generate_voucher_list();

            $scope.voucher_add_success = JSON.parse(res.data);
            $('#vou_add_success').fadeIn().delay(5000).fadeOut();
			

        },function (res) {
            //console.log(res);
        });
		
		//  }
    /*console.log('vou type id-----', $scope.voucher_type_id);
      console.log('vou type date------', $scope.voucher_date);
      console.log('debit_ledger_ld-----', $scope.debit_ledger_ld);
      console.log('debit_amount------', $scope.debit_amount);
      console.log('credit_ledger_ld-----', $scope.credit_ledger_ld);
      console.log('credit_amount------', $scope.credit_amount);*/

    }
}]);



