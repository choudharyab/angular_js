var importchequedetailsmodule=angular.module('importchequedetailsmodule',[]);
importchequedetailsmodule.controller('importDetailsController',['$rootScope','$scope','$location','$http','getsalecontractListService','bankAgentAutoCompleteService','getSaleContractDetailsByIDService','getBankDetails','taxesService','getImportPaymentListService','getImportPaymentByIdService',
    function($rootScope,$scope,$location,$http,getsalecontractListService,bankAgentAutoCompleteService,getSaleContractDetailsByIDService,getBankDetails,taxesService,getImportPaymentListService,getImportPaymentByIdService){
      
        $scope.importpayment={};
        $scope.importpayment.buyers_credit=false;
        $scope.import_title='Add Payment Details';
        $scope.show_edit_btn = false;
        $scope.show_save_btn = false;
        $scope.active_lable = false;

        getsalecontractListService({}).then(function(response){
            $scope.saleContractList=response.data;
        });

        $scope.popup_reset = function(){
            $scope.importpayment={};
            $scope.importpayment.buyers_credit=false;
            $scope.import_title='Add Payment Details';
            $scope.show_edit_btn = false;
            $scope.show_save_btn = false;
            $scope.active_lable = false;
            $scope.selected_data='';
            $scope.sale_contract_id='';
        }

        $scope.details_by_sale_id=function(){
            getSaleContractDetailsByIDService({sale_contract_id:$scope.sale_contract_id}).then(function(res){
                $scope.selected_data=res.data[0];
                $scope.importpayment.warehouse_id=$scope.selected_data.warehouse_id;
                $scope.importpayment.sale_contract_id=$scope.sale_contract_id;
            })
        }

        $scope.bankList = function(){
            getBankDetails({}).then(function (response) {
                $scope.bank_list = response.data;
                console.log('$scope.bank_list--->',$scope.bank_list);
            });
        }
        $scope.bankList();

        $scope.tax_data =function (index) {
            taxesService().then(function (response) {
                 $scope.tax_list = response.data;
               console.log($scope.tax_list);
            },function (response) {
                alert(response.data.error);
            });
        };
        $scope.tax_data();

        var auto_agent_array;
        $scope.get_auto_agent = function (term) {
            //console.log($scope.agent_name_auto);
            console.log(term);
            bankAgentAutoCompleteService({term:term}).then(function (res) {
                auto_agent_array = res.data;
                console.log(res.data);
                $scope.auto_search_agent_list = res.data;
            });
        };

        $scope.$watch('importpayment.issue_date',function () {

            var cal_days = $scope.selected_data.purchase_order.payment_term.payment_term_desc.match(/\d/g);
    
            cal_days = cal_days.join("");
    
            var date = new Date($scope.importpayment.issue_date);
            var newdate = new Date(date);
    
            newdate.setDate(newdate.getDate() + parseInt(cal_days));
    
            var dd = newdate.getDate();
            var mm = newdate.getMonth() + 1;
            var y = newdate.getFullYear();
    
            var someFormattedDate = y +'-'+mm + '-' + dd ;
            $scope.importpayment.lc_released_date=someFormattedDate;
           // document.getElementById('payment_date').value = someFormattedDate;
        });

        $scope.$watch('importpayment.extension_days',function () {
            if($scope.importpayment.extension_days){
                var cal_days = $scope.importpayment.extension_days;
    
                // cal_days = cal_days.join("");
         
                 var date = new Date($scope.importpayment.issue_date);
                 var newdate = new Date(date);
         
                 newdate.setDate(newdate.getDate() + parseInt(cal_days));
         
                 var dd = newdate.getDate();
                 var mm = newdate.getMonth() + 1;
                 var y = newdate.getFullYear();
         
                 var someFormattedDate = y +'-'+mm + '-' + dd ;
            
                 $scope.importpayment.payment_due_date=someFormattedDate;
            }
           
           // document.getElementById('payment_date').value = someFormattedDate;
        });

        $scope.cal_amount=function(){
            $scope.importpayment.amount_inr=$scope.importpayment.amount_usd*$scope.importpayment.dollor_rate_conversion;
            $scope.importpayment.amount_inr=$scope.importpayment.amount_inr.toFixed(2);
        }
    
        $(document).ready(function() {
            $('#auto_agent_code_id').on('input', function() {
                var userText = $(this).val();
    
                $("#agent-datalist").find("option").each(function() {
                    if ($(this).val() == userText) {
                        var index = auto_agent_array.findIndex(x => x.value==$(this).val());
    
                        $scope.importpayment.bank_agent_id = auto_agent_array[index].id;
                        // $scope.po_supplier_name = auto_agent_array[index].value;
                        // $scope.po_supplier_name = auto_agent_array[index].value.slice(6);
                        $scope.selected_agent_id = auto_agent_array[index].id;
    
                    }
                })
            })
        });

        $scope.tax_cal=function(tax){
            $scope.selected_tax=(JSON.parse(tax));
            $scope.importpayment.tax_id=$scope.selected_tax.id;
           // console.log($scope.selected_tax.tax_rate);
            if($scope.importpayment.amount_inr){
               
                if($scope.importpayment.commission_amount){
                    $scope.temp=parseFloat($scope.importpayment.amount_inr)+parseFloat($scope.importpayment.commission_amount);
                    $scope.importpayment.tax_amount=$scope.temp*parseFloat($scope.selected_tax.tax_rate)/100;
                    $scope.importpayment.tax_amount=$scope.importpayment.tax_amount.toFixed(2);
                    $scope.importpayment.total_amount=parseFloat($scope.importpayment.tax_amount)+parseFloat($scope.importpayment.amount_inr);
                }else{
                    $scope.importpayment.commission_amount=0;
                    $scope.temp=parseFloat($scope.importpayment.amount_inr)+parseFloat($scope.importpayment.commission_amount);
                    $scope.importpayment.tax_amount=$scope.temp*parseFloat($scope.selected_tax.tax_rate)/100;
                    $scope.importpayment.tax_amount=$scope.importpayment.tax_amount.toFixed(2);
                    $scope.importpayment.total_amount=parseFloat($scope.importpayment.tax_amount)+parseFloat($scope.importpayment.amount_inr);
                }
            }else{
                alert("Enter Conversion Rate")
            }
            
        }

        $scope.$on("selectedInvoice", function (event, args) {
            $scope.$apply(function () {
                $scope.attach_file = args.file;
    
                console.log($scope.attach_file);
            });
        });

        $scope.save_payment = function () {

     
            $http({
                method: 'POST',
                url: appUrl+'add_importpayment?token='+localStorage.getItem('token'),
                headers: { 'Content-Type': undefined },
    
                transformRequest: function (data) {
    
                    var formData = new FormData();
    
                    formData.append("import_payment", angular.toJson(data.model));
    
                    formData.append('attach_file',$scope.attach_file);
    
                    return formData;
                },
                data: {model: $scope.importpayment,attach_file: $scope.attach_file}
    
            }).success(function (res) {
    
                $scope.importpayment = {};
                $scope.attach_file='';
                $scope.sale_contract_id = '';
                $scope.agent_name_auto='';
                $scope.paymentlisting();
                $scope.dismiss();
                $('#chequeDetailSuccess').fadeIn().delay(5000).fadeOut();
                $scope.cheque_detail_success = "Import Payment Details Added Successfully";
    
            }).error(function (res) {
    
                if(res.error){
                    alert(res.error);
                }else{
                    alert("Import Payment Not Save");
                }
                
            });
    
        };
  
        $scope.paymentlisting=function(){
            getImportPaymentListService({}).then(function(res){
                $scope.importPayment_list=res.data;
            })
        }
        $scope.paymentlisting();

        // $scope.save_sup_cheque_status=function () {
        //     supChequeStatus({
        //         status:$scope.status,
        //         cleared_date:$scope.cleared_date,
        //         comments:$scope.comments,
        //         cheque_id:ch_id
        //     }).then(function (response) {
        //         $scope.otp_modal_dismiss();
        //         $scope.getSupplierChequelist();
        //     },function (response) {
        //         console.log(response);
        //     })
        // }

        $scope.edit_payment_details=function(imp_id){
            $scope.show_edit_btn = true;
            $scope.show_save_btn = true;
            $scope.active_lable = true;
            $scope.import_title='Edit Payment Details';
            getImportPaymentByIdService({import_payment_id:imp_id}).then(function(res){
                $scope.importpayment=res.data[0];
                console.log($scope.importpayment.buyers_credit);
                $scope.importpayment.import_payment_id=imp_id;
                $scope.sale_contract_id=res.data[0].sale_contract_id;
                $scope.agent_name_auto=res.data[0].bank_agent.agent_name;
                $scope.details_by_sale_id();
            })
        }
       

        $scope.update_payment = function () {

        ['created_at','updated_at','id','status','comment_status','delete_status','bank_agent','cleared_date','sale_contract','created_date'].forEach(function (t) {
            delete  $scope.importpayment[t];
         });
     
            $http({
                method: 'POST',
                url: appUrl+'update_import_payment?token='+localStorage.getItem('token'),
                headers: { 'Content-Type': undefined },
    
                transformRequest: function (data) {
    
                    var formData = new FormData();
    
                    formData.append("import_payment", angular.toJson(data.model));
    
                    formData.append('attach_file',$scope.attach_file);
    
                    return formData;
                },
                data: {model: $scope.importpayment,attach_file: $scope.attach_file}
    
            }).success(function (res) {
    
                $scope.importpayment = {};
                $scope.attach_file='';
                $scope.sale_contract_id = '';
                $scope.agent_name_auto='';
                $scope.selected_data='';
                $scope.paymentlisting();
                $scope.dismiss();
                $('#chequeDetailSuccess').fadeIn().delay(5000).fadeOut();
                $scope.cheque_detail_success = "Import Payment Details Update Successfully";
    
            }).error(function (res) {
    
                if(res.error){
                    alert(res.error);
                }else{
                    alert("Import Payment Not Update");
                }
                
            });
    
        };

    }]);