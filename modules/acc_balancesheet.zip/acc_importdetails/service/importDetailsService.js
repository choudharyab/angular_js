supplierchequedetailsmodule.factory('getsalecontractListService',function($http){
    return function (params) {
        return $http.get(appUrl+'get_sale_contract_listing_for_import_payment?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('bankAgentAutoCompleteService',function($http){
    return function (params) {
        return $http.get(appUrl+'bank_agent_autocomplete?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getSaleContractDetailsByIDService',function($http){
    return function (params) {
        return $http.get(appUrl+'get_sale_contract_details_by_id_for_import_payment?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getBankList',function($http){
    return function (params) {
        return $http.get(appUrl+'bank_account_list?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getImportPaymentListService',function($http){
    return function (params) {
        return $http.get(appUrl+'get_import_payment_listing?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getImportPaymentByIdService',function($http){
    return function (params) {
        return $http.get(appUrl+'get_import_payment_details_by_id?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getChequeDetailsById',function($http){
    return function (params) {
        return $http.get(appUrl+'cheque_details_by_id?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('editSupplierChequeDetails',function($http){
    return function (params) {
        return $http.post(appUrl+'update_cheque_details_by_id?token='+localStorage.getItem('token'),
            $.param(params),{headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            })
    }
}).factory('addChequeDetails',function($http){
    return function (params) {
        console.log('params-->',params);
        return $http.post(appUrl+'add_supplier_cheque_details?token='+localStorage.getItem('token'),
            $.param(params),{headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            })
    }
}).factory('supChequeStatus',function($http){
    return function (params) {
        console.log('params-->',params);
        return $http.post(appUrl+'change_cheque_status?token='+localStorage.getItem('token'),
            $.param(params),{headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            })
    }
})
;
