var accountLedgerAccModule = angular.module('accountLedgerAccModule',[]);
accountLedgerAccModule.controller('accountLedgerAccController',['$rootScope','$scope','$location','$routeParams','getAccLedgerAcountListService','getWarehouseListService','getAccLedgerAcountDetailsService',function($rootScope,$scope,$location,$routeParams,getAccLedgerAcountListService,getWarehouseListService,getAccLedgerAcountDetailsService){

    var ledgeraccdetail;


 $scope.finance_year = new Date().getFullYear();
    $scope.current_month = new Date().getMonth();
    if($scope.current_month<3){
        $scope.finance_year--;
    }
    $scope.current_month++;
    $rootScope.from_date = $scope.finance_year +'-04'+'-01';
    $rootScope.to_date = $scope.finance_year+1+'-03'+'-31';
 
    getWarehouseListService({}).then(function (response) {
        $scope.warehouse_list = response.data;
 
    });

	$scope.selected_warehouse = localStorage.getItem('warehouse_id');
    $scope.get_wh = function () {
        $rootScope.warehouse_id = $scope.warehouse_id;
        for(i=0;i<$scope.warehouse_list.length;i++){
            if($scope.warehouse_list[i].id==$scope.warehouse_id)
            $scope.warehouse_data=$scope.warehouse_list[i];
        }
        localStorage.setItem('warehouse_id',($scope.warehouse_data).id);
        localStorage.setItem('warehouse_name',($scope.warehouse_data).warehouse_name);
        console.log('warehouse_name----->',localStorage.getItem('warehouse_name'));
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
        $rootScope.selected_warehouse_name = localStorage.getItem('warehouse_name');
        //$route.reload();
    };

    $scope.$on('change_warehouse',function(event,data){
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
        $scope.ledger_account_list();
  $scope.get_po_warehouse();
    });

     $scope.get_po_warehouse = function () {
        localStorage.setItem('warehouse_id',$rootScope.warehouse_id);
        
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
    };


	$scope.ledger_account_list = function () {
        getAccLedgerAcountListService({from_date:$scope.from_date,
            to_date:$scope.to_date}).then(function (response) {
            $scope.ledgerAccountList = response.data;
            ledgeraccdetail=response.data.ledger_account_data;
        })
    };
    $scope.ledger_account_list();

    $scope.ledgerAccountdetails=function(ind,opening_bal,total_debit,total_credit,pdc_bal,closing_bal,uc_amount){
		
		$scope.opening_balance = opening_bal;
		$scope.total_debit = total_debit;
		$scope.total_credit = total_credit;
		$scope.pdc_balance = pdc_bal;
		$scope.uc_amount = uc_amount;
		$scope.closing_balance = closing_bal;
		//$scope.closing_balance = $scope.closing_balance.toFixed(2);
        /**if(ledgeraccdetail[ind].total_debit==null || ledgeraccdetail[ind].total_debit==undefined){
            ledgeraccdetail[ind].total_debit=0;
        }
        if(ledgeraccdetail[ind].total_credit==null || ledgeraccdetail[ind].total_credit==undefined){
            ledgeraccdetail[ind].total_credit=0;
        }
        $scope.ledgerDetails = ledgeraccdetail[ind];
        ledgeraccdetail[ind].closing_balance =ledgeraccdetail[ind].opening_balance+ledgeraccdetail[ind].total_debit-ledgeraccdetail[ind].total_credit;**/

    }
	
    $scope.view_ledger_datewise=function(ledger_id,type,supplier_type){
		if(ledger_id != undefined){
			$location.path('/ledgerdatewise/'+ledger_id+'/'+type+'/'+supplier_type);
		}
		if($routeParams.ledger_id != undefined){
			getAccLedgerAcountDetailsService({
				ledger_id:$routeParams.ledger_id,
				type:$routeParams.type,
				from_date:$scope.from_date,
				to_date:$scope.to_date,
				supp_check:$routeParams.supplier_type,
			}).then(function(response){
				$scope.ledgerDateWise=response.data;
				/**var details_data = [{}];
				var new_bal = 0;
				angular.forEach($scope.ledgerDateWise.details, function(value, key){
					new_bal += (value.debit_amount - value.credit_amount);
					details_data[key] = {
						credit_amount : value.credit_amount,
						debit_amount : value.debit_amount,
						ledger_name : value.ledger_name,
						voucher_date : value.voucher_date,
						voucher_number : value.voucher_number,
						voucher_type_name : value.voucher_type_name,
						close_bal_val : new_bal
					};
				});
				$scope.newData = details_data;**/
				//console.log(details_data)
				//console.log('data-->',$rootScope.ledgerDateWise);
				
			});
		}
        
    }
	$scope.view_ledger_datewise();
	
	$scope.convertCrDr = function(value){
		var checkVal = value.toString().indexOf('-');
		if(checkVal === -1){
			return value+' DR';
		} else {
			var splitVal = value.toString().split('-');
			return splitVal[1]+' CR';
		}
	}
 
}]);