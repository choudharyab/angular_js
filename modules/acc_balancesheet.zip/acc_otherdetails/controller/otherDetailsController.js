var otherDetailsModule=angular.module('otherDetailsModule',[]);
otherDetailsModule.controller('otherDetailsController',['$rootScope','$scope','$location','getOtherChequeDetails','getParticularsDetails',
    'addOtherChequeDetails','deleteOtherChequeDetails','getOtherChequeDetailsById','getOtherBankList','editOthersChequeDetails','otherChequeStatus','getAllLedgers','getWarehouseListService','getBankDetails','getVoucherLedgerListService','getVoucherLedgerListForOpService',
    function($rootScope,$scope,$location,getOtherChequeDetails,getParticularsDetails,addOtherChequeDetails,deleteOtherChequeDetails,
             getOtherChequeDetailsById,getOtherBankList,editOthersChequeDetails,otherChequeStatus,getAllLedgers,getWarehouseListService,getBankDetails,getVoucherLedgerListService,getVoucherLedgerListForOpService){

    $scope.add_other_cheque_info=[{'particulars_id':'','cheque_no':'','cheque_date':'','cheque_amount':'','name_on_cheque':'','bank_name_on_cheque':'','bank_id':''}];

	$scope.active_lable = false;	
    var list;
    var other_cheque_id,other_cheque_list;

    getWarehouseListService({}).then(function (response) {
        $scope.warehouse_list = response.data;
    });

    $scope.get_wh = function () {
        $rootScope.warehouse_id = $scope.warehouse_id;
    };

    $scope.$on('change_warehouse',function(event,data){
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
        $scope.getOtherChequelist();
    });

    
    $scope.getBankAccountlist=function () {
        getBankDetails({}).then(function (response) {
            console.log(response);
            $scope.bank_list=response.data;
        },function(response){
            console.log(response);
        });
    };
    $scope.getBankAccountlist();

    $scope.getOtherChequelist=function (payment_status) {
        getOtherChequeDetails({
        from_date:$scope.from_date,
		to_date:$scope.to_date,
		bank_id:$scope.selected_bank,
		cheque_status:payment_status
        }).then(function (response) {
            console.log(response);
            $scope.other_cheque_list=response.data.cheque_data;
            list=response.data.cheque_data;
            $scope.total_cheque_amount=res.data.total_amount;
        },function(response){
            console.log(response);
        })
    };
    $scope.getOtherChequelist();

    $scope.add_other_cheque_details=function () {

        $scope.add_other_cheque_info.push({'cheque_no':'','cheque_date':'','cheque_amount':'','name_on_cheque':'','bank_name_on_cheque':'','bank_id':''});
    };

    $scope.remove_other_cheque_details=function (index) {
        $scope.add_other_cheque_info.splice(index,1);
    };
    $scope.reset_others_modal = function(){
        $scope.add_other_cheque_info=[{'particulars_id':'','cheque_no':'','cheque_date':'','cheque_amount':'','name_on_cheque':'','bank_name_on_cheque':'','bank_id':''}];
        $scope.particulars='';
        $scope.debit_amount = '';
        $scope.credit_amount = '';
        $scope.debit_autocom = '';
        $scope.credit_autocom = '';
        $scope.narration='';
    };

    $scope.getParticulars=function () {
        getParticularsDetails({}).then(function (response) {
            console.log(response);
            $scope.particulars_list=response.data;
        },function(response){
            console.log(response);
        })
    };
    $scope.getParticulars();
        $scope.getOtherBankAccountlist=function () {
            getOtherBankList({}).then(function (response) {
                console.log(response);
                $scope.other_bank_list=response.data;
            },function(response){
                console.log(response);
            })
        };
        $scope.getOtherBankAccountlist();

        $scope.add_other_cheque=function () {

            console.log('-------',$scope.particulars);
          //  var particulars = JSON.parse($scope.particulars);
            for(var i=0;i< $scope.add_other_cheque_info.length;i++){

             //   $scope.add_other_cheque_info[i].particulars_id = particulars.id;
                $scope.add_other_cheque_info[i].ledger_id = $scope.ledger_id;
               // $scope.add_other_cheque_info[i].particulars = particulars.ledger_name;
                console.log($scope.add_other_cheque_info[i]);
       }


            console.log("======================================");
           // console.log($scope.add_other_cheque_info.particulars);
            console.log('$scope.add_other_cheque_info---------->',$scope.add_other_cheque_info);
            console.log("JSON");
            console.log(JSON.stringify($scope.add_other_cheque_info));

            addOtherChequeDetails({
                cheque_details:$scope.add_other_cheque_info,
                debit_particulars_id:$scope.debit_ledger_ld,
                debit_amount:$scope.debit_amount,
                credit_particulars_id:$scope.credit_ledger_ld,
                credit_amount:$scope.credit_amount,
                narration: $scope.narration,
				credit_ledger_type:$scope.credit_ledger_type,
				debit_ledger_type:$scope.debit_ledger_type,
				cheque_mode:$scope.cheque_mode,
            }).then(function (response) {
                console.log(response);
                $scope.dismiss();
                $scope.getOtherChequelist();
                $scope.debit_amount = '';
                $scope.credit_amount = '';
                $scope.debit_autocom = '';
                $scope.credit_autocom = '';
                $scope.narration='';
                for (var i=0;i<$scope.add_other_cheque_info.length;i++)
                {
                    $scope.add_other_cheque_info[i].cheque_no='';
                    $scope.add_other_cheque_info[i].cheque_date='';
                    $scope.add_other_cheque_info[i].cheque_amount='';
                    $scope.add_other_cheque_info[i].bank_name_on_cheque='';
                    $scope.add_other_cheque_info[i].name_on_cheque='';
                    $scope.add_other_cheque_info[i].bank_id='';
                }
                $scope.particulars='';
                $('#chequeDetailSuccess').fadeIn().delay(5000).fadeOut();
                $scope.cheque_detail_success = "Cheque Details Added Successfully";
                $scope.cheque_detail_error = "";
            },function (response) {
                console.log(response);
                $scope.cheque_detail_success = '';
                $('#chequeDetailError').fadeIn().delay(5000).fadeOut();
                //$scope.cheque_detail_error = response.data.error[0];
            })
        };

        $scope.deleteOtherChequeList=function (id) {

            deleteOtherChequeDetails({
                cheque_id:id
            }).then(function (response) {
                console.log(response);
                $scope.getOtherChequelist();
            })
        };


        $scope.edit_other_cheque_details=function (index,id) {
            console.log($scope.cheque_id);
            other_cheque_id=id;
            getOtherChequeDetailsById({
                cheque_id:id
            }).then(function (response) {
                console.log('response-->',response.data);
                $scope.edit_other_cheque_info=response.data[0];
                other_cheque_list=response.data[0];
				$scope.active_lable = true;
            });
        };

        $scope.update_other_cheque_details=function () {
            editOthersChequeDetails({
                cheque_id:other_cheque_id,
                cheque_no:$scope.edit_other_cheque_info.cheque_no,
                cheque_date:$scope.edit_other_cheque_info.cheque_date,
                cheque_amount:$scope.edit_other_cheque_info.cheque_amount,
                name_on_cheque:$scope.edit_other_cheque_info.name_on_cheque,
                bank_name_on_cheque:$scope.edit_other_cheque_info.bank_name_on_cheque,
                bank_id:$scope.edit_other_cheque_info.bank_id,
                invoice_id:other_cheque_list.invoice_id

            }).then(function (response) {
                console.log(response);
                console.log("===========================================");
                $scope.modal_dismiss_two();
                $scope.getOtherChequelist();
                $('#chequeDetailSuccess').fadeIn().delay(5000).fadeOut();
                $scope.cheque_detail_success = "Cheque Details Updated Successfully";
                $scope.cheque_detail_error = "";
            },function (response) {
                console.log(response);
                $scope.cheque_detail_success = '';
                $('#chequeDetailError1').fadeIn().delay(5000).fadeOut();
                $scope.cheque_detail_error1 = response.data.error[0];
            })
        };

        var ch_id;
        $scope.other_cheque_status=function (ind,id) {

            ch_id=id;
            $scope.cleared_date=list[ind].cleared_date;
            $scope.comments=list[ind].comments;
            $scope.status=list[ind].cheque_status;

        };

        $scope.save_other_cheque_status=function () {
            otherChequeStatus({
                status:$scope.status,
                cleared_date:$scope.cleared_date,
                comments:$scope.comments,
                cheque_id:ch_id
            }).then(function (response) {
                console.log(response);
                console.log("===========================================");
                $scope.otp_modal_dismiss();
                $scope.getOtherChequelist();
            },function (response) {
                console.log(response);
            })
        }

        
    $scope.get_ledger_data=function () {
        getAllLedgers({}).then(function (response) {
            console.log(response);
            $scope.ledger_data = response.data
        },function(response){
            console.log(response);
        })
    };
    $scope.get_ledger_data();

    
    $scope.$watch('debit_autocom',function () {
        $scope.get_debit_auto();
      });
  
      $scope.$watch('credit_autocom',function () {
          $scope.get_credit_auto();
      });
  
      $scope.get_debit_auto = function () {
  
          $('#debit_autocom').autocomplete({
              source:led_list,
              select:function (event,ui) {
                  console.log(ui);
                  $scope.debit_ledger_ld = ui.item.id;
				  $scope.debit_ledger_type = ui.item.ledger_type;
              }
          });
      };
  
      $scope.get_credit_auto = function () {
  
          $('#credit_autocom').autocomplete({
              source:led_list,
              select:function (event,ui) {
                  $scope.credit_ledger_ld = ui.item.id;
				  $scope.credit_ledger_type = ui.item.ledger_type;
              }
          });
      };
      $scope.copy_debit_amt = function () {
        $scope.credit_amount=$scope.debit_amount;
      };
  

      
   /* $scope.get_ledger_list = function () {
        getVoucherLedgerListService({}).then(function (response) {
            $scope.led_list = response.data;
            for(var f=0;f<$scope.led_list.length;f++){
                $scope.led_list[f].value = $scope.led_list[f].ledger_name+'-'+ $scope.led_list[f].bank_account_no;
            }
            led_list = $scope.led_list;
        })
    };
    $scope.get_ledger_list(); */
    
      $scope.get_ledger_list = function () {
        getVoucherLedgerListForOpService({}).then(function (response) {
            $scope.led_list = response.data;
            for(var f=0;f<$scope.led_list.length;f++){
                $scope.led_list[f].value = $scope.led_list[f].ledger_name+'-'+ $scope.led_list[f].bank_account_no;
            }
            led_list = $scope.led_list;
        })
    };
    $scope.get_ledger_list();


}]);



