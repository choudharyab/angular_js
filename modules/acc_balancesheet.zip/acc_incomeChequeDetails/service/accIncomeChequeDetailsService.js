accIncomeChequeDetailsmodule.factory('getAccIncomeChequeListService',function($http){
    return function (params) {
        return $http.get(appUrl+'cheque_listing_for_income_details?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getAccIncomeChequeTypeService',function($http){
    return function (params) {
        return $http.get(appUrl+'get_data_by_account_cheque_type?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getAccIncomeParticularTypeService',function($http){
    return function (params) {
        return $http.get(appUrl+'get_data_by_order_no_for_income_details?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getBankList',function($http){
    return function (params) {
        return $http.get(appUrl+'bank_account_list?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('addAccIncomeChequeDeatilsService',function($http){
    return function (params) {
        return $http.post(appUrl+'add_multiple_cheque_details_for_income_details?token='+localStorage.getItem('token'),
            $.param(params),{headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
            })
    }
}).factory('customerAutocomplete',function($http){
    return function (params) {
        return $http.get(appUrl+'customer_supplier_autocomplete?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
}).factory('getGenerateChequePrintingService',function($http){
    return function (params) {
        return $http.get(appUrl+'generate_cheque_printing?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
        })
    }
})
// .factory('getChequeDetailsById',function($http){
//     return function (params) {
//         return $http.get(appUrl+'cheque_details_by_id?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
//         })
//     }
// }).factory('editSupplierChequeDetails',function($http){
//     return function (params) {
//         return $http.post(appUrl+'update_cheque_details_by_id?token='+localStorage.getItem('token'),
//             $.param(params),{headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
//             })
//     }
// }).factory('deleteSupplierChequeDetails',function($http){
//     return function (params) {
//         return $http.get(appUrl+'delete_cheque_details?token='+localStorage.getItem('token')+'&warehouse_id='+localStorage.getItem('warehouse_id'),{params:params,header:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'}
//         })
//     }
// }).factory('supChequeStatus',function($http){
//     return function (params) {
//         console.log('params-->',params);
//         return $http.post(appUrl+'change_cheque_status?token='+localStorage.getItem('token'),
//             $.param(params),{headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}
//             })
//     }
// })
;
