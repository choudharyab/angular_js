var accIncomeChequeDetailsmodule=angular.module('accIncomeChequeDetailsmodule',[]);
accIncomeChequeDetailsmodule.controller('accIncomeChequeDetailsController',['$rootScope','$http','$scope','$timeout','$route','$location','$window','getAccIncomeChequeListService','getAccIncomeChequeTypeService','getAccIncomeParticularTypeService','getBankList','addAccIncomeChequeDeatilsService','getChequeDetailsById','editSupplierChequeDetails','deleteSupplierChequeDetails','supChequeStatus','getBankDetails','customerAutocomplete','getWarehouseListService','getVoucherLedgerListService','getVoucherLedgerListForOpService','getGenerateChequePrintingService',
function($rootScope,$http,$scope,$timeout,$route,$location,$window,getAccIncomeChequeListService,getAccIncomeChequeTypeService,getAccIncomeParticularTypeService,getBankList,addAccIncomeChequeDeatilsService,getChequeDetailsById,editSupplierChequeDetails,deleteSupplierChequeDetails,supChequeStatus,getBankDetails,customerAutocomplete,getWarehouseListService,getVoucherLedgerListService,getVoucherLedgerListForOpService,getGenerateChequePrintingService){
    var hiddenTokenData = localStorage.getItem('token');
    $scope.hiddentoken  = hiddenTokenData;    

    $scope.customer_id = '';
    var name;
    $scope.OpenPop = function(){
        $route.reload();
        $timeout(function () {
            $('#example2').modal('show');
            $scope.getAccountChequeList();
        },700);
    }
    $scope.check_disable = true;
    
    getWarehouseListService({}).then(function (response) {
        $scope.warehouse_list = response.data;
    });

    $scope.get_wh = function () {
        $rootScope.warehouse_id = $scope.warehouse_id;
  $scope.get_po_warehouse();
    };

    $scope.get_po_warehouse = function () {
        localStorage.setItem('warehouse_id',$rootScope.warehouse_id);
      
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
    };

    $scope.$on('change_warehouse',function(event,data){
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
        $scope.getAccountChequeList();
    });
	
    $scope.get_po_warehouse = function () {
        localStorage.setItem('warehouse_id',$rootScope.warehouse_id);
       
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');
    };

    $scope.getAccountChequeList = function(payment_status){
        getAccIncomeChequeListService({
        from_date:$scope.from_date,
		to_date:$scope.to_date,
		bank_id:$scope.selected_bank,
		cheque_status:payment_status
        }).then(function (res) { 
        	console.log(res)  
            $scope.cheque_list = res.data.cheque_data;
            $scope.total_cheque_amount=res.data.total_amount;
        },function (res) {
        
        });
    }
    $scope.getAccountChequeList();

    // $scope.getBankAccountlist=function () {
    //     getBankList({}).then(function (response) {
    //         console.log(response);
    //         $scope.bank_list=response.data;
    //     },function(response){
    //         console.log(response);
    //     });
    // };
    // $scope.getBankAccountlist();

    $scope.add_cheque_info=[{'cheque_no':'','cheque_date':'','cheque_amount':'','name_on_cheque':'','bank_name_on_cheque':'','bank_id':'','invoice':[]}];
    $scope.add_cheque_details=function () {
        $scope.add_cheque_info.push({'cheque_no':'','cheque_date':'','cheque_amount':'','name_on_cheque':name,'bank_name_on_cheque':'','bank_id':''});
        //$scope.add_cheque_info[$index].name_on_cheque = 
    };

    
    $scope.remove_cheque_details=function (index) {
        $scope.add_cheque_info.splice(index,1);
    }
    
    $scope.getBankAccountlist=function () {
        getBankDetails({}).then(function (response) {
            console.log(response);
            $scope.bank_list=response.data;
        },function(response){
            console.log(response);
        });
    };
    $scope.getBankAccountlist();

    var auto_customer_array
    $scope.searchCustomer = function(){
        customerAutocomplete({term:$scope.party_name}).then(function (res) {
            auto_customer_array = res.data;
            $scope.getCustomer();
        },function (res) {
           
        });
    }

    $scope.getCustomer = function(){
       $('#auto_customer_id').autocomplete({
            source:auto_customer_array,
            select:function (event,ui) {
                $scope.customer_id = ui.item.id;
                
                name = ui.item.value;
                $scope.add_cheque_info[0].name_on_cheque = ui.item.value;
				//$scope.cheque_type = ui.item.value;
				$scope.cheque_type_change();
            }
        });
    }  

    $scope.cheque_type_change = function(){
    	var cheque_type = this.cheque_type;
        if($scope.cheque_type == 'Income Old Invoice'){
            $scope.particularsList = '';
            $scope.check_disable = false;
            $scope.total_amount = '';
            $scope.remaining_amount = '';
            $scope.old_cheque_data = '';
            $scope.selected_inv_array = [];
            $scope.inv_array = [];
            t =0;

        }else{
	    $scope.particularsList = '';
            $scope.total_amount = '';
            $scope.remaining_amount = '';
            $scope.old_cheque_data = '';
            $scope.selected_inv_array = [];
            $scope.inv_array = [];
            t = 0;
            getAccIncomeChequeTypeService({
                id: $scope.customer_id,
                cheque_type : $scope.cheque_type
            }).then(function (res) { 
                console.log(res)  
                $scope.particularsList = res.data[0];
            },function (res) {
            
            });
            if($scope.total_amount > 0){
                $scope.check_disable = false;
            }else{
                $scope.check_disable = true;
            }
        }
    	
    }

    $scope.selected_inv_array = [];
    $scope.inv_array = [];
    $scope.amount =[];
    $scope.inv_obj={};
    $scope.old_cheque_data =[];
    var t = 0;
    $scope.check_if_checked = function(id,total){
        //if(document.getElementById('inv_check_'+id).checked == true){
            $scope.total_amount = 0;
            if($scope.selected_inv_array.indexOf(id) <= -1){
                $scope.inv_obj={
                    'order_id':id,
                    'grand_total':total
                };
                $scope.selected_inv_array.push(id);
                $scope.inv_array.push($scope.inv_obj);

                $scope.inv_obj = {};
                if($scope.particularsList.length == $scope.selected_inv_array.length){
                    $scope.selectedAll = true;
                }else{
                    $scope.selectedAll = false;

                }

            }else{
                $scope.inv_array.splice($scope.inv_array.indexOf(id),1);
                $scope.selected_inv_array.splice($scope.selected_inv_array.indexOf(id),1);

                if($scope.particularsList.length == $scope.selected_inv_array.length){
                    $scope.selectedAll = true;
                }else{
                    $scope.selectedAll = false;
                }

            }
            
            console.log($scope.inv_array);
            //$scope.add_cheque_info = $scope.inv_array;
            for(var i=0;i<$scope.inv_array.length;i++){
                $scope.total_amount = parseFloat($scope.total_amount) + parseFloat($scope.inv_array[i].grand_total);
            }
            $scope.add_cheque_info.grand_total = $scope.total_amount;
            //$scope.remaining_amount = 0;
            
            if(document.getElementById('inv_check_'+id).checked == true){
                getAccIncomeParticularTypeService({
                    id : id,
                    cheque_type: $scope.cheque_type
                }).then(function (res) { 
                    
                    if(res.data.cheque_data.length>0){
                        $scope.arr = [];
                        for(var i =0;i< res.data.cheque_data.length;i++){                            
                            $scope.arr.push(res.data.cheque_data[i]);
                        }
                        $scope.old_cheque_data = $scope.arr;
                    }

                    t = (parseFloat(t) + parseFloat(res.data.remaining_amount)).toFixed(2);
                    console.log('t---------',t);   
                    $scope.remaining_amount = t;              
                    //$scope.amount.push(res.data.remaining_amount);
                },function (res) {
                
                });
                //$scope.remaining_amount = t;
                // console.log($scope.amount);
                // for(var k=0;k<$scope.amount.length;k++){
                //     console.log($scope.amount[k]);
                //     $scope.remaining_amount = parseFloat($scope.remaining_amount) + parseFloat($scope.amount[k]);
                // }
            }else{
                $scope.old_cheque_data = '';
                getAccIncomeParticularTypeService({
                    id : id,
                    cheque_type: $scope.cheque_type
                }).then(function (res) { 
                    t = (parseFloat(t) - parseFloat(res.data.remaining_amount)).toFixed(2);
                    console.log('t---------',t);   
                    $scope.remaining_amount = t;              
                    //$scope.amount.push(res.data.remaining_amount);
                },function (res) {
                
                });

            }
        //}
    }

    

    

    $scope.get_particulars_type = function(){
    	var cheque_type = this.cheque_type;
    	var order_id = this.particulars_type;
    	getAccIncomeParticularTypeService({
    		id : order_id,
    		cheque_type: cheque_type
    	}).then(function (res) { 
            $scope.order_date = res.data.order_data.order_date;
            $scope.party_name = res.data.order_data.party_name;
            $scope.grand_total = res.data.order_data.grand_total;
            $scope.old_cheque_data = res.data.cheque_data;
            $scope.remaining_amount = res.data.remaining_amount;
        },function (res) {
        
        });
    }

    //Get Image Files
    $scope.files = [];
    
    //Get Image Files
    $scope.$on("seletedFile", function (event, args) {  
        $scope.$apply(function () {  
            $scope.files.push(args.file);  
        });  
    }); 
    
    $scope.save_cheque_data = function(){
        $('#saveCheque').hide();
            $('#showLoad').show();
            addAccIncomeChequeDeatilsService({
                cheque_details : $scope.add_cheque_info,
                cheque_type : $scope.cheque_type,
                party_id: $scope.customer_id,
                debit_particulars_id:$scope.debit_ledger_ld,
                debit_amount:$scope.debit_amount,
                credit_particulars_id:$scope.credit_ledger_ld,
                credit_amount:$scope.credit_amount,
                narration: $scope.narration,
				credit_ledger_type:$scope.credit_ledger_type,
				debit_ledger_type:$scope.debit_ledger_type,
				cheque_mode:$scope.cheque_mode,
                //invoice : $scope.inv_array
                //order_id : $scope.particulars_type,
            }).then(function (res) { 
                $scope.getAccountChequeList();
                if($scope.files.length > 0){
                    $http({
                        method: 'POST',
                        url: appUrl+'cheque_detail_upload?token='+$scope.hiddentoken+'&cheque_type='+$scope.cheque_type+'&order_id='+$scope.particulars_type,
                        headers: { 'Content-Type': undefined },
                        transformRequest: function (data) {
                            var formData = new FormData();
                            for(var i = 0; i < data.files.length; i++){
                                formData.append('cheque_file', data.files[i]);
                            }
                            return formData;
                        },
                        data: {'files': $scope.files}
                    }).
                    success(function (data, status, headers, config) {
                        $('#saveCheque').show();
                        $scope.debit_amount = '';
                        $scope.credit_amount = '';
                        $scope.debit_autocom = '';
                        $scope.credit_autocom = '';
                        $('#showLoad').hide();
                        $('#example2').modal('hide');
                        $scope.cheque_detail_success = 'Cheque details has been added successfully.';
                        $('#cheque_detail_success').fadeIn().delay(3000).fadeOut();
                       
                    }).
                    error(function (data, status, headers, config) {
                        $('#saveCheque').show();
                        $('#showLoad').hide();
                        alert('Error!');
                    });
                } else {
                    $('#saveCheque').show();
                    $scope.debit_amount = '';
                    $scope.credit_amount = '';
                    $scope.debit_autocom = '';
                    $scope.credit_autocom = '';
                    $scope.narration='';
                    $('#showLoad').hide();
                    $('#example2').modal('hide');
                    $scope.cheque_detail_success = 'Cheque details has been added successfully.';
                    $('#cheque_detail_success').fadeIn().delay(3000).fadeOut();
                }
                
            },function (res) {
            
            }); 
    }

    $scope.add_multiple_cheque = function(){
        
        for(var i=0;i<$scope.add_cheque_info.length;i++){
            //for(var j=0;j<$scope.inv_array.length;j++){
                $scope.add_cheque_info[i].invoice=$scope.inv_array;
                //$scope.add_cheque_info[i].party_id = $scope.customer_id;
            //}
            
        }
        //$scope.add_cheque_info.push($scope.inv_array);
        var sum = 0;
        angular.forEach($scope.add_cheque_info, function(value, key){
          sum += Number(value.cheque_amount); 
        });
        if($scope.cheque_type == 'Income Old Invoice'){
            $scope.save_cheque_data();
        }else{
        if($scope.remaining_amount < sum){
            $scope.cheque_detail_error_msg = 'Cheque amount should not be greater than remaining amount.';
            $('#cheque_detail_error_msg').fadeIn().delay(3000).fadeOut();
        }else{
            $scope.save_cheque_data();
        }
    }
        
    }

    $scope.edit_cheque_details=function (index,id) {
        var_cheque_id=id;
        getChequeDetailsById({
            cheque_id:id,
        }).then(function (response) {
            console.log('response-->',response.data);
            $scope.edit_cheque_info=response.data[0];
            cheque_list=response.data[0];
              $scope.active_lable = true;
        });
    }

    $scope.update_cheque_details=function () {
        editSupplierChequeDetails({
            cheque_id:var_cheque_id,
            cheque_no:$scope.edit_cheque_info.cheque_no,
            cheque_date:$scope.edit_cheque_info.cheque_date,
            cheque_amount:$scope.edit_cheque_info.cheque_amount,
            name_on_cheque:$scope.edit_cheque_info.name_on_cheque,
            bank_name_on_cheque:$scope.edit_cheque_info.bank_name_on_cheque,
            bank_id:$scope.edit_cheque_info.bank_id,
            invoice_id:cheque_list.invoice_id,
            type:'purchase'
        }).then(function (response) {
            //console.log(response);
            $scope.modal_dismiss_two();
            $scope.getAccountChequeList();

            $('#chequeDetailSuccess').fadeIn().delay(5000).fadeOut();
            $scope.cheque_detail_success = "Cheque Details Updated Successfully";
            $scope.cheque_detail_error = "";
        },function (response) {
            console.log(response);
            $scope.cheque_detail_success = '';
            $('#chequeDetailError1').fadeIn().delay(5000).fadeOut();
            $scope.cheque_detail_error1 = response.data.error[0];
        })
    };

    $scope.deleteSupplierChequeList=function (id) {
        deleteSupplierChequeDetails({
            cheque_id:id
        }).then(function (response) {
            console.log(response);
            $scope.getAccountChequeList();
        })
    };

    var ch_id;
    $scope.sup_cheque_status=function (ind,id) {

        ch_id=id;
        $scope.cleared_date=list[ind].cleared_date;
        $scope.comments=list[ind].comments;
        $scope.status=list[ind].cheque_status;
    };

    $scope.save_sup_cheque_status=function () {
        supChequeStatus({
            status:$scope.status,
            cleared_date:$scope.cleared_date,
            comments:$scope.comments,
            cheque_id:ch_id
        }).then(function (response) {
            //console.log(response);
            $scope.otp_modal_dismiss();
            $scope.getAccountChequeList();
        },function (response) {
            console.log(response);
        })
    }

    
    $scope.$watch('debit_autocom',function () {
        $scope.get_debit_auto();
      });
  
      $scope.$watch('credit_autocom',function () {
          $scope.get_credit_auto();
      });
  
      $scope.get_debit_auto = function () {
  
          $('#debit_autocom').autocomplete({
              source:led_list,
              select:function (event,ui) {
                  console.log(ui);
                  $scope.debit_ledger_ld = ui.item.id;
				  $scope.debit_ledger_type = ui.item.ledger_type;
              }
          });
      };
  
      $scope.get_credit_auto = function () {
  
          $('#credit_autocom').autocomplete({
              source:led_list,
              select:function (event,ui) {
                  $scope.credit_ledger_ld = ui.item.id;
				  $scope.credit_ledger_type = ui.item.ledger_type;
              }
          });
      };
      $scope.copy_debit_amt = function () {
        $scope.credit_amount=$scope.debit_amount;
      };
  

      
    // $scope.get_ledger_list = function () {
    //     getVoucherLedgerListService({}).then(function (response) {
    //         $scope.led_list = response.data;
    //         for(var f=0;f<$scope.led_list.length;f++){
    //             $scope.led_list[f].value = $scope.led_list[f].ledger_name+'-'+ $scope.led_list[f].bank_account_no;
    //         }
    //         led_list = $scope.led_list;
    //     })
    // };
    // $scope.get_ledger_list();

    $scope.get_ledger_list = function () {
        getVoucherLedgerListForOpService({}).then(function (response) {
            $scope.led_list = response.data;
            for(var f=0;f<$scope.led_list.length;f++){
                $scope.led_list[f].value = $scope.led_list[f].ledger_name+'-'+ $scope.led_list[f].bank_account_no;
            }
            led_list = $scope.led_list;
        })
    };
    $scope.get_ledger_list();
	
	 $scope.generate_cheque_print = function ($id) {
		 
		  $window.open(appUrl+'generate_cheque_printing?cheque_id=' + $id + '&token='+localStorage.getItem('token'));
		  
       /* getGenerateChequePrintingService({
			cheque_id: $id
		}).then(function (res) {
              $window.open(appUrl+'generate_cheque_printing?token='+localStorage.getItem('token'));
            //$('.loading').hide();
        })*/
    };

}]);
