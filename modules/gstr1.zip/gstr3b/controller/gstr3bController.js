var gstr3bModule = angular.module('gstr3bModule',[]);
gstr3bModule.controller('gstr3bController',['$rootScope','$scope','$location','$route','$timeout','$window','getWarehouseListService','getGstr3bService','generateJsonGstr3bService','generateExcelGstr3bService',function($rootScope,$scope,$location,$route,$timeout,$window,getWarehouseListService,getGstr3bService,generateJsonGstr3bService,generateExcelGstr3bService){
	
	
	getWarehouseListService({}).then(function (response) {
        $scope.warehouse_list = response.data;
    });
	
	$scope.selected_warehouse = localStorage.getItem('warehouse_id');
    $scope.get_po_warehouse = function () {
		$scope.changeAllData();
        /**localStorage.setItem('warehouse_id',JSON.parse($scope.warehouse_id).id);
        localStorage.setItem('warehouse_name',JSON.parse($scope.warehouse_id).warehouse_name);
        localStorage.setItem('warehouse_state_id',JSON.parse($scope.warehouse_id).state_id);
        $scope.selected_warehouse = localStorage.getItem('warehouse_id');**/
    };
	  $scope.get_data_by_date = function () {
		$scope.changeAllData();
      };
	$scope.changeAllData = function(){
		$('.loading').show();
		getGstr3bService({
			month : $scope.month,
			year : $scope.year,
			warehouse_id : $scope.warehouse_id,
			from_date : $scope.from_date,
			to_date : $scope.to_date,
		}).then(function (response) {
			$('.loading').hide();
			
			//outward_taxable_supplies_data
			$scope.central_tax = response.data.outward_taxable_supplies_data.central_tax;
			$scope.cess = response.data.outward_taxable_supplies_data.cess;
			$scope.integrated_tax = response.data.outward_taxable_supplies_data.integrated_tax;
			$scope.state_tax = response.data.outward_taxable_supplies_data.state_tax;
			$scope.total_taxable_value = response.data.outward_taxable_supplies_data.total_taxable_value;
			
			//all_other_itc
			$scope.integrated_tax_itc = response.data.all_other_itc.integrated_tax;
			$scope.central_tax_itc = response.data.all_other_itc.central_tax;
			$scope.state_tax_itc = response.data.all_other_itc.state_tax;
			$scope.cess_itc = response.data.all_other_itc.cess;
			
			//itc_reversed
			$scope.other_integrated_tax = response.data.itc_reversed.other_integrated_tax;
			$scope.other_central_tax = response.data.itc_reversed.other_central_tax;
			$scope.other_state_tax = response.data.itc_reversed.other_state_tax;
			$scope.other_cess = response.data.itc_reversed.other_cess;
			
			//net_itc_available
			$scope.integrated_tax_available = response.data.net_itc_available.integrated_tax;
			$scope.central_tax_available = response.data.net_itc_available.central_tax;
			$scope.state_tax_available = response.data.net_itc_available.state_tax;
			$scope.cess_available = response.data.net_itc_available.cess;
			
			//warehouse data
			$scope.gst_no_value = response.data.warehouse_data.gst_no;
			$scope.warehouse_name_value = response.data.warehouse_data.warehouse_name;
			
		});
	}
	
	$scope.generate_json_gstr3b = function () {
		/**if($scope.month == undefined){
			alert('Please select month')
		} else if($scope.year == undefined){
			alert('Please select year')
		} else if($scope.warehouse_id == undefined){
			alert('Please select warehouse')
		} else {
			$('.loading').show();
			generateJsonGstr3bService({
				month : $scope.month,
				year : $scope.year,
				warehouse_id : $scope.warehouse_id,
			}).then(function (response) {
				//console.log(response)
				var file_name= response.data.file_name;
				$scope.jsonfileName = file_name;
				$timeout(function () {
					$('.loading').hide();
					$('#genrJson').hide();
					$('#dowJson').show();
				},700);
			},function (res) {
				console.log(res);
			}); 
		}**/
        
    }
	
	
	$scope.generate_excel_gstr3b = function () {
        $('.loading').show();
        generateExcelGstr3bService({
            month : $scope.month,
			year : $scope.year,
			warehouse_id : $scope.warehouse_id,
			from_date : $scope.from_date,
			to_date : $scope.to_date,
        }).then(function (response) {
            //console.log(response)
            $window.open('Elephantoserver/public/excel_files/GSTR3B.xlsx');
            $('.loading').hide();
        },function (res) {
            console.log(res);
        }); 
    }
	
}]);
